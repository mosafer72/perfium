@extends('Admin.app')

@section('title', 'ایجاد دسته‌بندی جدید')

@section('content')
    <div class="content">
        <div class="header d-flex item-center bg-white width-100 border-bottom padding-12-30">
            <div class="header__right d-flex flex-grow-1 item-center">
                <span class="bars"></span>
                <a class="header__logo" href="{{ url('/') }}"></a>
            </div>
            <div class="header__left d-flex flex-end item-center margin-top-2">
                <span class="account-balance font-size-12">موجودی : 2,500,000 تومان</span>
                <div class="notification margin-15">
                    <a class="notification__icon"></a>
                    <div class="dropdown__notification">
                        <div class="content__notification">
                            <span class="font-size-13">موردی برای نمایش وجود ندارد</span>
                        </div>
                    </div>
                </div>
                <a href="{{ route('logout') }}" class="logout" title="خروج"></a>
            </div>
        </div>

        <div class="breadcrumb">
            <ul>
                <li><a href="{{ route('dashboard') }}">پیشخوان</a></li>
                <li><a href="{{ route('admin.categories.index') }}">دسته‌بندی‌ها</a></li>
                <li><a href="#" class="is-active">ایجاد دسته‌بندی جدید</a></li>
            </ul>
        </div>

        <div class="main-content font-size-13">
            <div class="tab__box">
                <div class="tab__items">
                    <a class="tab__item" href="{{ route('admin.categories.index') }}">لیست دسته‌بندی‌ها</a>
                    <a class="tab__item is-active" href="{{ route('admin.categories.create') }}">ایجاد دسته‌بندی جدید</a>
                </div>
            </div>
            @if(session('success'))
                <div class="alert alert-success m-2 p-2">
                    {{ session('success') }}
                </div>
            @endif

            @if(session('error'))
                <div class="alert alert-danger">{{ session('error') }}</div>
            @endif

            @if ($errors->any())

                <div class="alert alert-danger">
                    <ul class="m-0">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
            <div class="form__box">
                <form action="{{ route('admin.categories.store') }}" method="POST"
                    class="padding-30 bg-white border-radius-3">
                    @csrf

                    <div class="row no-gutters">

                        {{-- عنوان دسته --}}
                        <div class="col-12 margin-bottom-15">
                            <label class="label">عنوان دسته‌بندی</label>
                            <input type="text" name="name" value="{{ old('name') }}" class="input" required>
                            @error('name')
                                <span class="text-error">{{ $message }}</span>
                            @enderror
                        </div>

                        {{-- اسلاگ --}}
                        <div class="col-12 margin-bottom-15">
                            <label class="label">اسلاگ (برای آدرس URL)</label>
                            <input type="text" name="slug" value="{{ old('slug') }}" class="input"
                                placeholder="مثلاً men-perfume">
                            <small class="text-gray">اگر خالی بگذاری، از روی عنوان ساخته می‌شود.</small>
                            @error('slug')
                                <span class="text-error">{{ $message }}</span>
                            @enderror
                        </div>

                        {{-- تصویر دسته (آیکن) --}}
                        <div class="col-12 margin-bottom-15">
                            <label class="label">آدرس تصویر دسته</label>
                            <input type="text" name="image" value="{{ old('image', 'assets/images/category/cat-1.png') }}"
                                class="input">
                            <small class="text-gray">مثلاً: assets/images/category/cat-1.png</small>
                            @error('image')
                                <span class="text-error">{{ $message }}</span>
                            @enderror
                        </div>

                        {{-- توضیحات کوتاه (مثلاً سبک عطر) --}}
                        <div class="col-12 margin-bottom-15">
                            <label class="label">توضیحات</label>
                            <textarea name="description" class="input" rows="2">{{ old('description') }}</textarea>
                        </div>

                        {{-- ترتیب نمایش --}}
                        <div class="col-12 margin-bottom-15">
                            <label class="label">ترتیب نمایش</label>
                            <input type="number" name="sort_order" value="{{ old('sort_order', 0) }}" class="input" min="0"
                                max="255">
                        </div>

                        {{-- نمایش در صفحه اصلی --}}
                        <div class="col-12 margin-bottom-15">
                            <label class="d-flex item-center">
                                <input type="checkbox" name="show_in_home" value="1" {{ old('show_in_home', 1) ? 'checked' : '' }}>
                                <span class="margin-right-10">نمایش در صفحه اصلی</span>
                            </label>
                        </div>

                        {{-- وضعیت --}}
                        <div class="col-12 margin-bottom-15">
                            <label class="label">وضعیت</label>
                            <select name="status" class="input">
                                <option value="active" {{ old('status') == 'active' ? 'selected' : '' }}>فعال</option>
                                <option value="inactive" {{ old('status') == 'inactive' ? 'selected' : '' }}>غیرفعال</option>
                            </select>
                        </div>

                        <div class="col-12 margin-top-20">
                            <button type="submit" class="btn btn-brand">ایجاد دسته‌بندی</button>
                            <a href="{{ route('admin.categories.index') }}" class="btn btn-gray">بازگشت</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

@endsection
